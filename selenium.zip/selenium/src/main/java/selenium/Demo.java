package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo {
	static WebDriver driver = null;

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.co.in/");
		driver.findElement(By.xpath("//input[@id='lst-ib']")).sendKeys("dheerajdbd");
		driver.findElement(By.xpath("//input[@name='btnK']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Images')]")).click();
		this.takeSnapShot(driver, "c://test.png") ;    
		driver.findElement(By.id("d1hMyfjjr-1tnM:")).click();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
		}
		driver.findElement(By.xpath("//*[@id='irc_cc']/div[2]/div[3]/div[1]/div/table[1]/tbody/tr/td[1]/a")).click();
	}
	// driver.close();
}
